<?php $__env->startSection('content'); ?>


<div class="container">
<div class="row">
    <div class="col-md-6">
      <h3>Qaleriya</h3>
    </div>
    <div class="col-md-offset-4 col-md-2">
    <button type="button" style="margin-top:12px" class="btn btn-success" data-toggle="modal" data-target="#modal">Əlave et</button>

      <div id="modal" class="modal fade" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Şəkil yaxud video əlavə et</h4>
            </div>
            <form action="<?php echo e(url('/admin/gallery/create')); ?>" method="post"  enctype="multipart/form-data">
            
            <div class="modal-body">

                <div class="form-group">
                  <?php echo csrf_field(); ?>
                  <label for="name">Başlıq</label>
                  <input name="caption" type="text" class="form-control"  id="name"  placeholder="Adı daxil edin" required>
                </div>
                <div class="form-group">
                  <label for="name">Şəkil/Video</label>
                  <select name="type" class="form-control" id="">
                    <option value="0">Şəkil</option>
                    <option value="1">Video</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="file" style="border: 1px solid #e3e3e3; border-style:dashed; padding: 10px 15px; cursor: pointer">Foto seçin</label>
                  <input type="file" style="display:none" name="file" id="file">
                </div>

            </div>
            <div class="modal-footer">
              <input type="submit" value="Əlave et" class="btn btn-success">
              <button type="button" class="btn btn-default" data-dismiss="modal">İmtina et</button>
            </div>
            </form>
            
          </div>

        </div>
      </div>
    </div>
  </div>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Başlıq</th>
        <th>Şəkil(Video)</th>
        <th>Action</th>
        <th>Akitv/Deaktiv</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td> <?php echo e($gallery->id); ?>.
          <?php echo e($gallery->caption); ?></td>
        <td>
          <?php if($gallery->type == 0): ?>
          <img height="100" src="/<?php echo e($gallery->source); ?>" alt="">
          <?php elseif($gallery->type ==1): ?>
          <video height="100" src="/<?php echo e($gallery->source); ?>"></video>
          <?php endif; ?>

        </td>
        <td>
          <button type="button" class="btn btn-default" data-toggle="modal" data-target="#update<?php echo e($gallery->id); ?>">Redakte</button>

          <div id="update<?php echo e($gallery->id); ?>" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Silməyə əminsiz?</h4>
                </div>
                <form action="<?php echo e(url('/admin/gallery/update')); ?>" method="post">
                <div class="modal-body">
                  <div class="form-group">
                    <?php echo csrf_field(); ?>
                    <label for="name">Başlıq</label>
                    <input name="caption" type="text" class="form-control"  id="name"  value="<?php echo e($gallery->caption); ?>" required>
                  </div>
                </div>
                <input type="hidden" name="id" value="<?php echo e($gallery->id); ?>">
                <div class="modal-footer">
                  <input type="submit" value="Dəyiş" class="btn btn-success">
                  <button type="button" class="btn btn-default" data-dismiss="modal">İmtina et</button>
                </div>
                </form>
              </div>

            </div>
          </div>

          <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#<?php echo e($gallery->id); ?>">Sil</button>

          <div id="<?php echo e($gallery->id); ?>" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Silməyə əminsiz?</h4>
                </div>
                <div class="modal-body">
                  <p>Bir dəfə silindəkdən sonrə qaleriya əlavə et düyməsindən yenidən əlavə edə bilərsiz. </p>
                </div>
                <div class="modal-footer">
                  <a href="<?php echo e(url('/admin/gallery/delete').'/'.$gallery->id); ?>" class="btn btn-danger">Sil</a>
                  <button type="button" class="btn btn-default" data-dismiss="modal">İmtina et</button>
                </div>
              </div>

            </div>
          </div>

          

        </td>
        <td>
          <form action="<?php echo e(url('/admin/gallery/active')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($gallery->id); ?>" name="id">
            <?php if($gallery->active == 0): ?>
              <input type="submit" class="btn btn-secondary" value="Active et">
            <?php else: ?>
              <input type="submit" class="btn btn-dark" value="Deactive et">
            <?php endif; ?>
          </form>
        </td>
      </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php echo e($galleries->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>