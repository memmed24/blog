<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row">
    <div class="col-md-6">
      <h3>Adminlər</h3>
    </div>
    <div class="col-md-offset-4 col-md-2">
    <button type="button" style="margin-top:12px" class="btn btn-success" data-toggle="modal" data-target="#modal">Əlave et</button>

      <div id="modal" class="modal fade" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Admin əlavə et</h4>
            </div>
            <form action="<?php echo e(url('/admin/create')); ?>" method="post">
            
            <div class="modal-body">

                <div class="form-group">
                  <?php echo csrf_field(); ?>
                  <label for="name">Ad</label>
                  <input name="name" type="text" class="form-control"  id="name"  placeholder="Adı daxil edin" required>
                </div>
                <div class="form-group">
                  <label for="surname">Soyad</label>
                  <input name="surname" type="text" class="form-control"  id="surname"  placeholder="Soyadı daxil edin" required>
                </div>
                <div class="form-group">
                  <label for="email">Email address</label>
                  <input name="email" type="email" class="form-control" id="email" placeholder="Email-i daxil edin" required>
                </div>
                <div class="form-group">
                  <label for="password">Şifrə</label>
                  <input name="password" type="password" class="form-control" id="password"  placeholder="Şifrəni daxil edin" required>
                </div>

            </div>
            <div class="modal-footer">
              <input type="submit" value="Əlave et" class="btn btn-success">
              <button type="button" class="btn btn-default" data-dismiss="modal">İmtina et</button>
            </div>
            </form>
            
          </div>

        </div>
      </div>
    </div>
  </div>

<table class="table table-hover">
    <thead>
      <tr>
        <th>Ad</th>
        <th>Soyad</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td><?php echo e($admin->name); ?></td>
        <td><?php echo e($admin->surname); ?></td>
        <td><?php echo e($admin->email); ?></td>
        <td>
          <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#<?php echo e($admin->id); ?>">Sil</button>

          <div id="<?php echo e($admin->id); ?>" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Adminlikdən silməyə əminsiz?</h4>
                </div>
                <div class="modal-body">
                  <p>Bir dəfə silindəkdən sonrə admin əlavə et-dən yenidən əlavə edə bilərsiz.</p>
                </div>
                <div class="modal-footer">
                  <a href="<?php echo e(url('/admin/remove').'/'.$admin->id); ?>" class="btn btn-danger">Sil</a>
                  <button type="button" class="btn btn-default" data-dismiss="modal">İmtina et</button>
                </div>
              </div>

            </div>
          </div>



          <button type="button" class="btn btn-alert" data-toggle="modal" data-target="#update<?php echo e($admin->id); ?>">Redakte</button>

            <div id="update<?php echo e($admin->id); ?>" class="modal fade" role="dialog">
              <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Redakte et</h4>
                  </div>
                  <form action="<?php echo e(url('/admin/update')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="modal-body">
                    <p>Adminin adını, soyadını və email-ini redakte et</p>
                      <div class="form-group">
                        <label for="name">Ad</label>
                        <input name="name" type="text" class="form-control"  id="name" value="<?php echo e($admin->name); ?>">
                      </div>
                      <div class="form-group">
                        <label for="surname">Soyad</label>
                        <input name="surname" type="text" class="form-control"  id="surname"  value="<?php echo e($admin->surname); ?>">
                      </div>
                      <input type="hidden" name="id" value="<?php echo e($admin->id); ?>">
                      <div class="form-group">
                        <label for="email">Email address</label>
                        <input name="email" type="email" class="form-control" id="email" value="<?php echo e($admin->email); ?>">
                      </div>
                  </div>
                  <div class="modal-footer">
                    <input type="submit" class="btn btn-success" value="Redakte et">
                    <!-- <a href="<?php echo e(url('/admin/remove').'/'.$admin->id); ?>" class="btn btn-danger">Redakte et</a> -->
                    <button type="button" class="btn btn-default" data-dismiss="modal">İmtina et</button>
                  </div>
                  </form>
                  
                </div>

              </div>
            </div>

        </td>
      </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<?php echo e($admins->links()); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>