<?php $__env->startSection('content'); ?>

 <div style="background:url('/img/1920x1080/01.jpg'); background-size: 100%; background-position: center" class="parallax-window" data-parallax="scroll" data-image-src="img/1920x1080/01.jpg">
            <div class="parallax-content container">
                <h1 class="carousel-title">

                  <?php if($lang == 'az'): ?>
                  Tezliklə...
                  <?php elseif($lang == 'en'): ?>
                  Coming soon...
                  <?php elseif($lang == 'ru'): ?>
                  Cкоро...
                  <?php endif; ?>

                </h1>
                
            </div>
        </div>
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>