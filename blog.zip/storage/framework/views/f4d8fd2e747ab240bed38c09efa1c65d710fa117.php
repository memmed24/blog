<!DOCTYPE html>
<!-- ==============================
    Project:        ACSC Logistics Website 2018
    Version:        1.0
    Author:         Bir inc.
    Primary use:    Corporate, Business.
    Email:          elshan.guliyev@unity-solutoins.az
    Like:           http://www.facebook.com/elshan23
    Website:        http://www.unity-solutions.az
================================== -->
<html lang="en" class="no-js">
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8"/>
        <title>ACSC Logistics &#8211; ACSC Logistics</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>
        <!-- GLOBAL MANDATORY STYLES -->
        <!-- <link href="<?php echo e(asset('http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700')); ?>" rel="stylesheet" type="text/css"> -->
        <link href="<?php echo e(asset('vendor/simple-line-icons/simple-line-icons.min.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
        <!-- PAGE LEVEL PLUGIN STYLES -->
        <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('vendor/swiper/css/swiper.min.css')); ?>" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/css/font-awesome.min.css')); ?>">

        <!-- THEME STYLES -->
        <link href="<?php echo e(asset('css/layout.min.css')); ?>" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>"/>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
        <link href="<?php echo e(asset('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        
        <!-- <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script> -->


    </head>
    <!-- END HEAD -->

    <!-- BODY -->
    <body style="font-family:Arial, Helvetica, sans-serif">

        <!--========== HEADER ==========-->
        <header class="header navbar-fixed-top">


           <!--  ELAVE OLUNDU -->
            <div class=" container-fulid">
                <div class="row">
                    <div class="col-sm-12 col-md-12 head">
                        <ul class="headul">
                            <li><i class="fa fa-mobile " aria-hidden="true"></i> <span><a style="color: white" href="tel:+994124043700">Tel:+994124043700</a></span></li>
                           <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <span><a style="color: white" href="mailto:office@logistics.acsc.az">office@logistics.acsc.az</a></span></li>
                            <li class="downlast"><i class="fa fa-globe" aria-hidden="true"></i> <span style="text-transform:uppercase"><?php echo e($lang); ?></span> <i class="fa fa-angle-down down" style="font-size: 15px;" aria-hidden="true"></i>

                                <ul class="headuldown">
                                    <li>
                                        <a style="color:white" href="<?php echo e(url('/az')); ?>">AZ</a>
                                    </li>
                                    <li>
                                        <a style="color:white" href="<?php echo e(url('/ru')); ?>">RUS</a>
                                    </li>
                                    <li>
                                        <a style="color:white" href="<?php echo e(url('/en')); ?>">ENG</a>
                                    </li>
                                </ul>

                            </li>
                        </ul>
                    </div>
                  
                </div>
            </div>

               <!--  SON -->



            <!-- Navbar -->
            <nav style="" class="navbar blurry" role="navigation">
                <div class="container" style="">
                    <!-- BACSC and toggle get grouped for better mobile display -->
                    <div class="menu-container">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="toggle-icon"></span>
                        </button>

                        <!-- Logo -->
                        <div class="logo">
                            <a class="logo-wrap" href="index.html">
                                <img class="logo-img logo-img-main" src="<?php echo e(asset('img/logo.png')); ?>" alt="Asentus Logo">
                                <img class="logo-img logo-img-active" src="<?php echo e(asset('img/logo-dark.png')); ?>" alt="Asentus Logo">
                            </a>
                        </div>
                        <!-- End Logo -->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse nav-collapse">
                        <div class="menu-container">
                            <ul class="navbar-nav navbar-nav-right">
                                <li class="nav-item"><a class="nav-item-child nav-item-hover active" href="<?php echo e(url('/'.$lang)); ?>">
                                    <?php if($lang ==  'az'): ?>
                                    Ana səhifə
                                    <?php elseif($lang == 'en'): ?>
                                    Main page
                                    <?php elseif($lang == 'ru'): ?>
                                    Главная
                                    <?php endif; ?>
                                </a>
                                </li>
                                <li class="nav-item compin "><a class="nav-item-child nav-item-hover" href="#"><?php if($lang ==  'az'): ?>
                                    Şirkət
                                    <?php elseif($lang == 'en'): ?>
                                    Company
                                    <?php elseif($lang == 'ru'): ?>
                                    Компания
                                    <?php endif; ?></a>

                                       <!--  ELAVE OLUNDU -->
                                    <ul class="compdown">
                                        <li ><a  href="<?php echo e(url($lang.'/about')); ?>"><?php if($lang ==  'az'): ?>
                                    Haqqımızda
                                    <?php elseif($lang == 'en'): ?>
                                    About us
                                    <?php elseif($lang == 'ru'): ?>
                                    О нас
                                    <?php endif; ?></a>
                                            </li>

                                         <li><a href="<?php echo e(url($lang.'/mission')); ?>"><?php if($lang ==  'az'): ?>
                                    Missiya
                                    <?php elseif($lang == 'en'): ?>
                                    Mission
                                    <?php elseif($lang == 'ru'): ?>
                                    Миссия
                                    <?php endif; ?></a>
                                        </li>
                                    </ul>

                                       <!--  ELAVE OLUNDU -->
                                </li>
                                <li class="nav-item infoin"><a class="nav-item-child nav-item-hover" href="#">
                                <?php if($lang ==  'az'): ?>
                                    Faydalı Məlumatlar
                                    <?php elseif($lang == 'en'): ?>
                                    Useful Information
                                    <?php elseif($lang == 'ru'): ?>
                                    Полезная Информация
                                    <?php endif; ?></a>
                                    <ul class="infodown">
                                        <li ><a  href="<?php echo e(url($lang.'/about')); ?>"><?php if($lang ==  'az'): ?>
                                    Xəbərlər
                                    <?php elseif($lang == 'en'): ?>
                                    News
                                    <?php elseif($lang == 'ru'): ?>
                                    Новости
                                    <?php endif; ?></a>
                                            </li>

                                         <li><a href="<?php echo e(url($lang.'/info')); ?>">
                                         <?php if($lang ==  'az'): ?>
                                         Məlumatlar
                                        <?php elseif($lang == 'en'): ?>
                                        Information
                                        <?php elseif($lang == 'ru'): ?>
                                        Информация
                                        <?php endif; ?></a>
                                        </li>
                                    </ul>
                                
                                </li>
                                <li class="nav-item servin"><a class="nav-item-child nav-item-hover" href="#">
                                    <?php if($lang ==  'az'): ?>
                                    Xidmətlər
                                    <?php elseif($lang == 'en'): ?>
                                    Services
                                    <?php elseif($lang ==  'ru'): ?>
                                    Услуги
                                    <?php endif; ?>
                                </a>


                                               <!--  ELAVE OLUNDU -->

                                        <ul class="servdown">
                                           <li ><a  href="<?php echo e(url($lang.'/shipping')); ?>">
                                            <?php if($lang ==  'az'): ?>
                                            Dəniz daşımaları
                                            <?php elseif($lang == 'en'): ?>
                                            Sea transportation
                                            <?php elseif($lang ==  'ru'): ?>
                                            Морские перевозки
                                            <?php endif; ?>
                                           </a>
                                            </li>

                                         <li><a href="<?php echo e(url($lang.'/railway')); ?>">
                                            <?php if($lang ==  'az'): ?>
                                            Dəmiryolu daşımaları
                                            <?php elseif($lang == 'en'): ?>
                                            Railway transportation
                                            <?php elseif($lang ==  'ru'): ?>
                                            Железнодорожные перевозки
                                            <?php endif; ?>
                                            </a>
                                        </li>
                                        <li ><a  href="<?php echo e(url($lang.'/auto')); ?>

                                            ">
                                            <?php if($lang == 'az'): ?>
                                            Avtomobil daşımaları
                                            <?php elseif($lang == 'en'): ?>
                                            Road transportation
                                            <?php elseif($lang == 'ru'): ?>
                                            Сухопутные перевозки
                                            <?php endif; ?>
                                            </a>
                                            </li>

                                         <li><a href="<?php echo e(url($lang.'/multi-modal')); ?>">
                                            <?php if($lang == 'az'): ?>
                                            Multi-modal daşımaları
                                            <?php elseif($lang == 'en'): ?>
                                            Multi-modal transportation
                                            <?php elseif($lang == 'ru'): ?>
                                            Мультимодальные перевозки
                                            <?php endif; ?> 
                                         </a>
                                        </li>
                                        <li ><a  href="<?php echo e(url($lang.'/door-to-door')); ?>">
                                            <?php if($lang == 'az'): ?>
                                            Qapıdan-qapıya daşıma
                                            <?php elseif($lang == 'en'): ?>
                                            Door-to-door transportation
                                            <?php elseif($lang == 'ru'): ?>
                                            Перевозки от двери к двери
                                            <?php endif; ?>
                                        </a>
                                            </li>

                                       
                                        </ul>

                                           <!--  ELAVE OLUNDU -->

                                </li>
                                <li class="nav-item recin"><a class="nav-item-child nav-item-hover" href="#">
                                    <?php if($lang == 'az'): ?>
                                    Tariflər
                                    <?php elseif($lang == 'en'): ?>
                                    Tariffs
                                    <?php elseif($lang == 'ru'): ?>
                                    Тарифы
                                    <?php endif; ?>
                                </a>
                                       <!--  ELAVE OLUNDU -->
                                    <ul class="recdown">
                                         <li><a href="<?php echo e(url($lang.'/comingsoon')); ?>"><?php if($lang ==  'az'): ?>
                                            Dəniz daşımaları
                                            <?php elseif($lang == 'en'): ?>
                                            Sea transportation
                                            <?php elseif($lang ==  'ru'): ?>
                                            Морские перевозки
                                            <?php endif; ?></a>
                                        </li>
                                        <li ><a  href="<?php echo e(url($lang.'/comingsoon')); ?>"><?php if($lang ==  'az'): ?>
                                            Dəmiryolu daşımaları
                                            <?php elseif($lang == 'en'): ?>
                                            Railway transportation
                                            <?php elseif($lang ==  'ru'): ?>
                                            Железнодорожные перевозки
                                            <?php endif; ?></a>
                                            </li>
                                    </ul>

                                       <!--  ELAVE OLUNDU -->
                                </li>
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="<?php echo e(url($lang.'/contact')); ?>">
                                <?php if($lang == 'az'): ?>
                                Əlaqə
                                <?php elseif($lang == 'en'): ?>
                                Contact
                                <?php elseif($lang == 'ru'): ?>
                                Контакты
                                <?php endif; ?>
                                </a></li>
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="#footer">
                                    <?php if($lang == 'az'): ?>
                                    Müraciət et
                                    <?php elseif($lang == 'en'): ?>
                                    Apply
                                    <?php elseif($lang == 'ru'): ?>
                                    Сообщение
                                    <?php endif; ?>
                                </a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Navbar Collapse -->
                </div>
            </nav>
            <!-- Navbar -->
        </header>
        <!--========== END HEADER ==========-->

        <!--========== SLIDER ==========-->
       <?php echo $__env->yieldContent('content'); ?>

        <!-- End Work -->
        <!--========== END PAGE LAYOUT ==========-->

        <!--========== FOOTER ==========-->
        <footer class="footer" id="footer">
            <!-- Links -->
            <div class="footer-seperator">
                <div class="content-lg container">
                    <div class="row">
                        <div class="col-sm-2 sm-margin-b-50">
                            <!-- List -->
                            <ul class="list-unstyled footer-list">
                                <?php if($lang == "az"): ?>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/az'); ?>">Ana səhifə</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/az/about'); ?>">Haqqımızda</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/az/mission'); ?>">Missiya</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/az/shipping'); ?>">Dəniz Daşımaları</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/az/railway'); ?>">Dəmiryolu Daşımaları</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/az/comingsoon')); ?>">Tariflər</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/az/contact')); ?>">Əlaqə</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="#">Müraciət et</a></li>
                                <?php elseif($lang == "en"): ?>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/en'); ?>">Main page</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/en/about'); ?>">About us</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/en/mission'); ?>">Mission</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/en/shipping'); ?>">Shipping Company</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/en/railway'); ?>">Railway transport</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/en/comingsoon')); ?>">Tariffs</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/en/contact')); ?>">Contact</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="#">Apply</a></li>
                                <?php elseif($lang == "ru"): ?>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/ru'); ?>">Главная страница</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/ru/about'); ?>">O нас</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/ru/mission'); ?>">Mиссия</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/ru/shipping'); ?>">Морское Пароходство</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/').'/ru/railway'); ?>">Железнодорожные перевозки</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/ru/comingsoon')); ?>">Tарифы</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="<?php echo e(url('/ru/contact')); ?>">Kонтакты</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="#">Подать заявление</a></li>
                                <?php endif; ?>
                                
                                
                            </ul>
                            <!-- End List -->
                        </div>
                        <div class="col-sm-4 sm-margin-b-30">
                            <!-- List -->
                            <div class="col-md-8">
                                    <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".3s">
                                        <h3><a href="#" style=" color: white">
                                            <?php if($lang == "az"): ?>
                                            Bakı / Azərbaycan
                                            <?php elseif($lang == "en"): ?>
                                            Baku / Azerbaijan
                                            <?php elseif($lang == "ru"): ?>
                                            Баку / Азербайджан
                                            <?php endif; ?>
                                        </a></h3>
                                        <ul class="list-unstyled contact-list">
                                            <li><i class="margin-r-10 color-base icon-call-out"></i>
                                                <a href="#" style="color: white">Tel: +994 12 404 37 00
                                                <br>
                                                (ext.3098)
                                                </a>
                                            </li>
                                            <li><i class="margin-r-10 color-base icon-call-out"></i>
                                                <a href="#" style="color: white">Tel: +994 50 243 91 83</a>
                                            </li>
                                            <li><i class="margin-r-10 color-base icon-envelope"></i>
                                                <a href="#" style="color: white">info@acsc.az</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            <!-- End List -->
                        </div>
                        <div class="col-sm-5 sm-margin-b-30">
                            <h2 class="color-white">
                                <?php if($lang == "az"): ?>
                                Əlaqə
                                <?php elseif($lang == "en"): ?>
                                Contact
                                <?php elseif($lang == "ru"): ?>
                                Kонтакты
                                <?php endif; ?>
                            </h2>
                            <form action="<?php echo e(url('/sendmail')); ?>" method="post">
                                <input type="text" class="form-control footer-input margin-b-20" name="name" placeholder="<?php if($lang == "az"): ?>Adınız
                                <?php elseif($lang == "en"): ?>Name
                                <?php elseif($lang == "ru"): ?>Имя
                            <?php endif; ?>" >
                                <?php echo csrf_field(); ?>

                                <input type="text" class="form-control footer-input margin-b-20" name="email" placeholder="<?php if($lang == "az"): ?>E-adress
                                <?php elseif($lang == "en"): ?>E-mail
                                <?php elseif($lang == "ru"): ?>Эл. адрес
                            <?php endif; ?>" >
                                <input type="text" class="form-control footer-input margin-b-20" name="number" placeholder="<?php if($lang == "az"): ?>Əlaqə nömrəsi
                                <?php elseif($lang == "en"): ?>Contact number
                                <?php elseif($lang == "ru"): ?>Контактный номер
                            <?php endif; ?>" >
                                <textarea class="form-control footer-input margin-b-30" rows="6" name="message" placeholder="<?php if($lang == "az"): ?>Mesajınız
                                <?php elseif($lang == "en"): ?>Feedback
                                <?php elseif($lang == "ru"): ?>Обратная связь
                            <?php endif; ?>" ></textarea>
                                <input name="ad" type="submit" class="btn-theme btn-theme-sm btn-base-bg text-uppercase" value="
                                    <?php if($lang == "az"): ?>Göndər
                                    <?php elseif($lang == "en"): ?>Send
                                    <?php elseif($lang == "ru"): ?>Отправлять
                                    <?php endif; ?>
                                ">
                            </form>
                        </div>
                    </div>
                    <!--// end row -->
                </div>
            </div>
            <!-- End Links -->

            <!-- Copyright -->
            <div class="content container">
                <div class="row">
                    <div class="col-xs-6">
                        <img class="footer-logo" src="<?php echo e(asset('img/logo.png')); ?>" alt="Asentus Logo">
                    </div>
                    <div class="col-xs-6 text-right">
                        <p class="margin-b-0"><a class="color-base fweight-700" href="http://keenthemes.com/preview/asentus/">Copyright © 2018</a> Powered by: <a class="color-base fweight-700" href="http://www.keenthemes.com/">Unity-solutions.az</a></p>
                    </div>
                </div>
                <!--// end row -->
            </div>
            <!-- End Copyright -->
        </footer>
        <!--========== END FOOTER ==========-->

        <!-- Back To Top -->
        <a href="javascript:void(0);" class="js-back-to-top back-to-top">Top</a>

        <!-- JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
        <!-- CORE PLUGINS -->
        <script src="<?php echo e(asset('vendor/jquery.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('vendor/jquery-migrate.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
           <!--  ELAVE OLUNDU -->
        <script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
           <!--  ELAVE OLUNDU -->
        <!-- PAGE LEVEL PLUGINS -->
        <!-- <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script> -->

        <script src="<?php echo e(asset('https://use.fontawesome.com/0c60faf74e.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/jquery.easing.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('vendor/jquery.back-to-top.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('vendor/jquery.smooth-scroll.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('vendor/jquery.wow.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('vendor/swiper/js/swiper.jquery.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('vendor/masonry/jquery.masonry.pkgd.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('vendor/masonry/imagesloaded.pkgd.min.js')); ?>" type="text/javascript"></script>

        <!-- PAGE LEVEL SCRIPTS -->
        <script src="<?php echo e(asset('js/layout.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/components/wow.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/components/swiper.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/components/masonry.min.js')); ?>" type="text/javascript"></script>

    </body>
    <!-- END BODY -->
</html>