<?php echo e($request->email); ?> terefinden gonderilen email


nomresi - <?php echo e($request->number); ?>


adi - <?php echo e($request->name); ?>



Mesaji:
<?php echo e($request->message); ?>