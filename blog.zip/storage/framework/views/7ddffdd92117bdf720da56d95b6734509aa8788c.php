<?php $__env->startSection('content'); ?>
<div  style="background:url('/img/1920x1080/01.jpg'); background-size: 100%; background-position: center" class="parallax-window" data-parallax="scroll" data-image-src="img/1920x1080/01.jpg">
            <div class="parallax-content container">
                <h1 class="carousel-title">
                  <?php if($lang == 'az'): ?>
                  Xəbərlər
                  <?php elseif($lang == 'en'): ?>
                  News
                  <?php elseif($lang == 'ru'): ?>
                  Новости
                  <?php endif; ?>
                </h1>
            </div>
        </div>
        <!--========== PARALLAX ==========-->

        <!--========== PAGE LAYOUT ==========-->
        <!-- Our Exceptional Solutions -->
        <div class="content-lg container">
            <!--// end row -->

            <div class="row margin-b-50">
                <!-- Our Exceptional Solutions -->
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news_): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 sm-margin-b-50">
                    <div class="margin-b-20">
                        <div class="wow zoomIn" data-wow-duration=".3" data-wow-delay=".1s">
                            <img style="height: 200px" class="img-responsive" src="<?php echo e(asset($news_->photo)); ?>" alt="Our Exceptional Solutions Image">
                        </div>
                    </div>
                    <h3><a href="<?php echo e(url($lang.'/news/'.$news_->id)); ?>"><?php echo e($news_->title_.$lang); ?></a> <span class="text-uppercase margin-l-20"><?php echo e($news_->getCategoryAttr()); ?></span></h3>
                    <p><?php echo e($news_->content_.$lang); ?></p>
                    <a class="link" href="<?php echo e(url($lang.'/news/'.$news_->id)); ?>">
                      <?php if($lang == 'az'): ?>
                      Daha çox...
                      <?php elseif($lang == 'en'): ?>
                      Read More...
                      <?php elseif($lang == 'ru'): ?>
                      Подробнее...
                      <?php endif; ?>
                    </a>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End Our Exceptional Solutions -->

            </div>
            <!--// end row -->
        <?php echo e($news->links()); ?>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>