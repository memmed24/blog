<?php $__env->startSection('content'); ?>

    <div style="background:url('/img/1920x1080/01.jpg'); background-size: 100%; background-position: center" class="parallax-window" data-parallax="scroll" data-image-src="<?php echo e(asset('img/1920x1080/01.jpg')); ?>">
        <div class="parallax-content container">
            <h1 class="carousel-title">
                <?php if($lang == 'az'): ?>
                    Qaleriya
                <?php elseif($lang == 'en'): ?>
                    Gallery
                <?php elseif($lang == 'ru'): ?>
                    галерея
                <?php endif; ?>
            </h1>

        </div>
    </div>

    <div class="content-lg container">
        <div class="row margin-b-20">
            <div class="col-sm-6">
                <h2>
                    <?php if($lang == 'az'): ?>
                        Qaleriya
                    <?php elseif($lang == 'en'): ?>
                        Gallery
                    <?php elseif($lang == 'ru'): ?>
                        галерея
                    <?php endif; ?>


                </h2>
            </div>
        </div>
        <!--// end row -->

        <div class="row">

            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <p><?php echo e($gallery->caption); ?></p>
                        <?php if($gallery->type == 0): ?>
                            <img src="/<?php echo e($gallery->source); ?>" alt="">
                        <?php elseif($gallery->type == 1): ?>
                            <video src="/<?php echo e($gallery->source); ?>"></video>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($galleries->links()); ?>


        </div>
        <!--// end row -->
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>