<?php $__env->startSection('content'); ?>

<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <div class="container">
            
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                </ol>
            </div>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox"> 
                <div class="item active">
                    <img class="img-responsive" src="<?php echo e(asset('img/1920x1080/01.jpg')); ?>" alt="Slider Image">
                   
                    <div class="container">
                        <div class="carousel-centered">
                            <div class="margin-b-40">
                                
                                <h1 class="carousel-title">
                                
                                <?php if($lang == "az"): ?>
 
                                “Qapıdan-qapıya” <br> daşıma

                                <?php elseif($lang == "en"): ?>

                                "Door-to-door" <br> transportation

                                <?php else: ?>

                                "Oт двери до двери" <br> транспорта

                                <?php endif; ?>
                                </h1>
                                <p></p>
                            </div>
                            <a href="#" class="btn-theme btn-theme-sm btn-white-brd text-uppercase"><?php if($lang == 'az'): ?>
                            Məlumat
                            <?php elseif($lang == 'en'): ?>
                            Info
                            <?php elseif($lang == 'ru'): ?>
                            Информация
                            <?php endif; ?></a>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <img class="img-responsive" src="<?php echo e(asset('img/1920x1080/railway.jpg')); ?>" alt="Slider Image">
                    <div class="container">
                        <div class="carousel-centered">
                            <div class="margin-b-40">
                            <h1 class="carousel-title">
                                
                                <?php if($lang == "az"): ?>
 
                                “Qapıdan-qapıya” <br> daşıma

                                <?php elseif($lang == "en"): ?>

                                "Door-to-door" <br> transportation

                                <?php else: ?>

                                "Oт двери до двери" <br> транспорта

                                <?php endif; ?>
                                </h1>
                                <p></p>
                            </div>                            
                            <a href="<?php echo e(url($lang.'/railway')); ?>" class="btn-theme btn-theme-sm btn-white-brd text-uppercase">
                            <?php if($lang == 'az'): ?>
                            Məlumat
                            <?php elseif($lang == 'en'): ?>
                            Info
                            <?php elseif($lang == 'ru'): ?>
                            Информация
                            <?php endif; ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--========== SLIDER ==========-->

    






        <!--========== PAGE LAYOUT ==========-->
        <!-- Service -->

        <div class="bg-color-sky-light" data-auto-height="true">
            <div class="content-lg container">
                <div class="row row-space-1 margin-b-2">
                    <div class="col-sm-4 sm-margin-b-2">
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".3s">
                            <div class="service" data-height="height">
                                <div class="service-element">
                                    <i class="icon-globe icons" style="color: #31465B; font-size: 50px"></i>

                                </div>
                                <div class="service-info" style="margin-top: 28px"> 
                                    <h3>
                                        <?php if($lang == 'az'): ?>
                                        Nəqliyyat və Çatdırma Həlləri
                                        <?php elseif($lang == 'en'): ?>
                                        Transportation and shipping solutions
                                        <?php elseif($lang == 'ru'): ?>
                                        Решения для транспортировки и доставки
                                        <?php endif; ?>
                                        </h3>
                                    <p class="margin-b-5">
                                        <?php if($lang == 'az'): ?>
                                        Bizimlə tərəfdaş şirkətlərə məxsus olan aktivlərdən istifadə etməyə imkan verir.
                                        <?php elseif($lang == 'en'): ?>
                                        Our partnerships allow us to leverage company-owned assets.
                                        <?php elseif($lang == 'ru'): ?>
                                        Наши партнерские отношения позволяют нам использовать активы, принадлежащие компании.
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 sm-margin-b-2">
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".2s">
                            <div class="service" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-screen-tablet" style="color: #31465B; font-size: 50px"></i>
                                </div>
                                <div class="service-info">
                                    <h3>
                                        <?php if($lang == 'az'): ?>
                                        Praktikadakı məsələlərin araşdırılması
                                        <?php elseif($lang == 'en'): ?>
                                        Explore Case Studies
                                        <?php elseif($lang == 'ru'): ?>
                                        Изучите примеры из практики
                                        <?php endif; ?>
                                    </h3>
                                    <p class="margin-b-5">
                                        <?php if($lang == 'az'): ?>
                                        Sənaye təchizat zəncirləri, saxlama və daşıma həlləri haqqında daha çox məlumat əldə edin.
                                        <?php elseif($lang == 'en'): ?>
                                        Learn more about our industry-specific supply chain, warehousing and distribution solutions.
                                        <?php elseif($lang == 'ru'): ?>
                                        Узнайте больше о наших отраслевых цепочках поставок, складских и дистрибуционных решениях.
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".1s">
                            <div class="service" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-badge" style="color: #31465B; font-size: 50px"></i>
                                </div>
                                <div class="service-info">
                                    <h3>
                                        <?php if($lang == 'az'): ?>
                                        Layihənin idarə olunması
                                        <?php elseif($lang == 'en'): ?>
                                        Project Management
                                        <?php elseif($lang == 'ru'): ?>
                                        Управление проектом
                                        <?php endif; ?>
                                    </h3>
                                    <p class="margin-b-5">
                                        <?php if($lang =='az'): ?>
                                        İstənilən ölçülü və miqyaslı layihələr üçün nəqliyyatı, saxlanması və paylanması üçün kompleks həllər.
                                        <?php elseif($lang == 'en'): ?>
                                        Comprehensive, scalable transportation, warehousing and distribution solutions for projects of any size and scope.
                                        <?php elseif($lang == 'ru'): ?>
                                        Комплексные, масштабируемые решения для транспортировки, складирования и распределения для проектов любого размера и масштаба.
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <a href="#" class="content-wrapper-link"></a>    
                            </div>
                        </div>
                    </div>
                </div>
                <!--// end row -->

                <div class="row row-space-1">
                    <div class="col-sm-4 sm-margin-b-2">
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".4s">
                            <div class="service" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-notebook" style="color: #31465B; font-size: 50px"></i>
                                </div>
                                <div class="service-info">
                                    <h3>
                                        <?php if($lang == 'az'): ?>
                                        Anbar xidmətləri
                                        <?php elseif($lang == 'en'): ?>
                                        Warehousing
                                        <?php elseif($lang == 'ru'): ?>
                                        Cкладирование
                                        <?php endif; ?>
                                    </h3>
                                    <p class="margin-b-5">
                                        <?php if($lang =='az'): ?>
                                        Ehtiyacları müəyyən edərkən, anbar ehtiyaclarını diqqətə almaq vacibdir.
                                        <?php elseif($lang =='en'): ?>
                                        In determining needs, one should look beyond the basic need of a warehouse to store things. Whilst, this is correct there are also other considerations.
                                        <?php elseif($lang == 'ru'): ?>
                                        При определении потребностей нужно смотреть за пределы основной потребности склада в хранении вещей. Хотя, это верно, есть и другие соображения.
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 sm-margin-b-2">
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".5s">
                            <div class="service" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-speedometer" style="color: #31465B; font-size: 50px"></i>
                                </div>
                                <div class="service-info">
                                    <h3>
                                        <?php if($lang == 'az'): ?>
                                        Sürətli çatdırma
                                        <?php elseif($lang == 'ru'): ?>
                                        Быстрая доставка
                                        <?php elseif($lang == 'en'): ?>
                                        Fast Delivery
                                        <?php endif; ?>
                                    </h3>
                                    <p class="margin-b-5">
                                        <?php if($lang == 'az'): ?>
                                        ACSC logistics ilə yükünüzü göndərdiyiniz zaman bu, beynəlxalq yükdaşıma və kuryer çatdırılması xidmətləri üzrə mütəxəssislər ilə göndərilirsiniz deməkdir! 
                                        <?php elseif($lang == 'en'): ?>
                                        When you ship with ACSC logistics – you’re shipping with specialists in international shipping and courier delivery services! 
                                        <?php elseif($lang == 'ru'): ?>
                                        Пользуясь услугами ACSC logistics - вы отправляете со специалистами в области международных перевозок и курьерской доставки!
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".6s">
                            <div class="service" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-badge" style="color: #31465B; font-size: 50px"></i>
                                </div>
                                <div class="service-info">
                                    <h3>
                                        <?php if($lang == 'az'): ?>
                                        Logistikanın doğru şəkildə idarə olunması
                                        <?php elseif($lang == 'en'): ?>
                                        Managing logistics the right way
                                        <?php elseif($lang == 'ru'): ?>
                                        Правильное управление логистикой
                                        <?php endif; ?>
                                    </h3>
                                    <p class="margin-b-5">
                                        <?php if($lang == 'az'): ?>
                                        Bizim əsas öhdəliyimiz effektiv beynəlxalq logistika infrastrukturunun yaradılmasıdır. Bu məqsədi nəzərə alaraq, müştərilərimiz üçün asanlıqla yerinə yetirmək üçün çox vaxt və resurslar sərf etdik.
                                        <?php elseif($lang == 'en'): ?>
                                        Our primary commitment is the establishment of an effective international logistics infrastructure. With this goal in mind, we have invested a great deal of time and resources to make fulfillment easy for our clients.
                                        <?php elseif($lang == 'ru'): ?>
                                        Нашей основной задачей является создание эффективной международной логистической инфраструктуры. С этой целью мы вложили много времени и ресурсов, чтобы удовлетворить потребности наших клиентов.
                                        <?php endif; ?>
                                    </p>
                                </div>
                                </div>
                        </div>
                    </div>
                </div>
                <!--// end row -->
            </div>
        </div>
        <!-- End Service -->

        <!-- Latest Products -->
        <div class="content-lg container">
            <div class="row margin-b-40">
                <div class="col-sm-6">
                    <h2>
                        <?php if($lang == 'az'): ?>
                        Xəbərlər
                        <?php elseif($lang == 'en'): ?>
                        News
                        <?php elseif($lang == 'ru'): ?>
                        Новости
                        <?php endif; ?>
                    </h2>
                    <p>
                        <?php if($lang == 'az'): ?>
                        Yeniliklərdən xəbərdar olmaq üçün abunə olub xəbərlərimizi e-poçtunuza ala bilərsiz!
                        <?php elseif($lang == 'ru'): ?>
                        Подпишитесь на обновления наших новостей и получите их по электронной почте!
                        <?php elseif($lang == 'en'): ?>
                        Subscribe to updates of our news and receive them on your email!
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            <!--// end row -->

            <div class="row">
                

                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news_): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 sm-margin-b-50">
                    <div class="margin-b-20">
                        <div class="wow zoomIn" data-wow-duration=".3" data-wow-delay=".1s">
                            <img style="height: 200px" class="img-responsive" src="<?php echo e(asset($news_->photo)); ?>" alt="Latest Products Image">
                        </div>
                    </div>
                    <h4><a href="#"><?php echo e($news_->title_.$lang); ?></a> <span class="text-uppercase margin-l-20">Sərgi</span></h4>
                    <p><?php echo e($news_->content_.$lang); ?></p>
                    <a class="link" href="<?php echo e(url($lang.'/news').'/'.$news_->id); ?>">Ətraflı</a>
                </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <!--// end row -->
        </div>
        <!-- End Latest Products -->

        <!-- Clients -->
        <div class="bg-color-sky-light">
            <div class="content-lg container">
                <!-- Swiper Clients -->
                <div class="swiper-slider swiper-clients">
                    <!-- Swiper Wrapper -->
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img class="swiper-clients-img" src="img/clients/01.png" alt="Clients Logo">
                        </div>
                        <div class="swiper-slide">
                            <img class="swiper-clients-img" src="img/clients/02.png" alt="Clients Logo">
                        </div>
                        <div class="swiper-slide">
                            <img class="swiper-clients-img" src="img/clients/03.png" alt="Clients Logo">
                        </div>
                        <div class="swiper-slide">
                            <img class="swiper-clients-img" src="img/clients/04.png" alt="Clients Logo">
                        </div>
                        <div class="swiper-slide">
                            <img class="swiper-clients-img" src="img/clients/05.png" alt="Clients Logo">
                        </div>
                        <div class="swiper-slide">
                            <img class="swiper-clients-img" src="img/clients/06.png" alt="Clients Logo">
                        </div>
                    </div>
                    <!-- End Swiper Wrapper -->
                </div>
                <!-- End Swiper Clients -->
            </div>
        </div>
        <!-- End Clients -->

        <!-- Testimonials -->
        <div class="content-lg container">
            <div class="row">
                <div class="col-sm-9">
                    <h2>Müştərilərimizin rəyləri</h2>

                    <!-- Swiper Testimonials -->
                    <div class="swiper-slider swiper-testimonials">
                        <!-- Swiper Wrapper -->
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <blockquote class="blockquote">
                                    <div class="margin-b-20">
                                        ACSC Logistics-in yüksək səviyyəli xidməti!
Mən Azərbaycana yük göndərməli idim və ACSC Logistics şirkətinin xidmətlərindən istifadə etmək qərarına gəldim.

Sifariş vermədən əvvəl internetdə logistika şirkətlərini araştırdım və veb saytdakı məlumatlardan faydalandım. Və danışıqlar apardıqdan sonra, çox məqbul bir qiymət verildi və məhz bu şirkəti seçdim. Çatdırılma çox sürətli idi - yalnız 48 saat sonra yük lazımlı ünvana çatdırıldı.


                                    </div>
                                    <div class="margin-b-20">
                                       Mən bu şirkətin xidmətlərindən yenidən istifadə edəcəyimə şübhə etmirəm və göstərilən kömək üçün təşəkkür edirəm. Hər kəsə çox tövsiyə olunur.
                                    </div>
                                    <p><span class="fweight-700 color-link">Elşən Quliyev</span></p>
                                </blockquote>
                            </div>
                            <div class="swiper-slide">
                                <blockquote class="blockquote">
                                    <div class="margin-b-20">
                                     ACSC Logistics-in yüksək səviyyəli xidməti!
Mən Azərbaycana yük göndərməli idim və ACSC Logistics şirkətinin xidmətlərindən istifadə etmək qərarına gəldim.

Sifariş vermədən əvvəl internetdə logistika şirkətlərini araştırdım və veb saytdakı məlumatlardan faydalandım. Və danışıqlar apardıqdan sonra, çox məqbul bir qiymət verildi və məhz bu şirkəti seçdim. Çatdırılma çox sürətli idi - yalnız 48 saat sonra yük lazımlı ünvana çatdırıldı.
                                    </div>
                                    <div class="margin-b-20">
                                        Mən bu şirkətin xidmətlərindən yenidən istifadə edəcəyimə şübhə etmirəm və göstərilən kömək üçün təşəkkür edirəm. Hər kəsə çox tövsiyə olunur.
                                    </div>
                                    <p><span class="fweight-700 color-link">Elşən Quliyev</span></p>
                                </blockquote>
                            </div>
                        </div>
                        <!-- End Swiper Wrapper -->

                        <!-- Pagination -->
                        <div class="swiper-testimonials-pagination"></div>
                    </div>
                    <!-- End Swiper Testimonials -->
                </div>
            </div>
            <!--// end row -->
        </div>
        <!-- End Testimonials -->
 
   





        <!-- Pricing -->
     <!--   <div class="bg-color-sky-light">
            <div class="content-lg container">
                <div class="row row-space-1">
                    <div class="col-sm-4 sm-margin-b-2">
                        <!-- Pricing -->
      <!--                  <div class="pricing">
                            <div class="margin-b-30">
                                <i class="pricing-icon icon-chemistry"></i>
                                <h3>Low <span> - $</span> 49</h3>
                                <p>Lorem ipsum dolor amet consectetur ut consequat siad esqudiat dolor</p>
                            </div>
                            <ul class="list-unstyled pricing-list margin-b-50">
                                <li class="pricing-list-item">Basic Features</li>
                                <li class="pricing-list-item">Up to 5 products</li>
                                <li class="pricing-list-item">50 Users Panels</li>
                            </ul>
                            <a href="pricing.html" class="btn-theme btn-theme-sm btn-default-bg text-uppercase">Choose</a>
                        </div>
                        <!-- End Pricing -->
         <!--           </div>
                    <div class="col-sm-4 sm-margin-b-2">
                        <!-- Pricing -->
         <!--               <div class="pricing pricing-active">
                            <div class="margin-b-30">
                                <i class="pricing-icon icon-badge"></i>
                                <h3>Professional <span> - $</span> 149</h3>
                                <p>Lorem ipsum dolor amet consectetur ut consequat siad esqudiat dolor</p>
                            </div>
                            <ul class="list-unstyled pricing-list margin-b-50">
                                <li class="pricing-list-item">Basic Features</li>
                                <li class="pricing-list-item">Up to 100 products</li>
                                <li class="pricing-list-item">100 Users Panels</li>
                            </ul>
                            <a href="pricing.html" class="btn-theme btn-theme-sm btn-default-bg text-uppercase">Choose</a>
                        </div>
                        <!-- End Pricing -->
       <!--             </div>
                    <div class="col-sm-4">
                        <!-- Pricing -->
        <!--                <div class="pricing">
                            <div class="margin-b-30">
                                <i class="pricing-icon icon-shield"></i>
                                <h3>Advanced <span> - $</span> 249</h3>
                                <p>Lorem ipsum dolor amet consectetur ut consequat siad esqudiat dolor</p>
                            </div>
                            <ul class="list-unstyled pricing-list margin-b-50">
                                <li class="pricing-list-item">Extended Features</li>
                                <li class="pricing-list-item">Unlimited products</li>
                                <li class="pricing-list-item">Unlimited Users Panels</li>
                            </ul>
                            <a href="pricing.html" class="btn-theme btn-theme-sm btn-default-bg text-uppercase">Choose</a>
                        </div>
                        <!-- End Pricing -->
      <!--              </div>
                </div>
                <!--// end row -->
  <!--          </div>
        </div>
        <!-- End Pricing -->

        <!-- Promo Section -->
    <!--    <div class="promo-section overflow-h">
            <div class="container">
                <div class="clearfix">
                    <div class="ver-center">
                        <div class="ver-center-aligned">
                            <div class="promo-section-col">
                                <h2>Our Clients</h2>
                                <p>Lorem ipsum dolor sit amet consectetur adipiscing elit sed tempor incididunt ut laboret dolore magna aliqua enim minim veniam exercitation ipsum dolor sit amet consectetur adipiscing elit sed tempor incididunt ut laboret dolore magna aliqua enim minim veniam exercitation</p>
                                <p>Ipsum dolor sit amet consectetur adipiscing elit sed tempor incididut ut sead laboret dolore magna aliqua enim minim veniam exercitation ipsum dolor sit amet consectetur adipiscing</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="promo-section-img-right">
                <img class="img-responsive" src="img/970x970/01.jpg" alt="Content Image">
            </div>
        </div>   -->
        <!-- End Promo Section -->


                    





        <!-- Work -->
        <div class="bg-color-sky-light overflow-h">
            <div class="content-lg container">
                <div class="row margin-b-40">
                    <div class="col-sm-6">
                        <h2>Faydalı Məlumatlar</h2>
                        <p>Konteynerlər, Vagonlar və Logistika ilə bağlı bir çox faydalı məlumatları burada əldə edə bilərsiz.</p>
                    </div>
                </div>
                <!--// end row -->

                <!-- Masonry Grid -->
                <div class="masonry-grid">
                    <div class="masonry-grid-sizer col-xs-6 col-sm-6 col-md-1"></div>
                    <div class="masonry-grid-item col-xs-12 col-sm-6 col-md-8">
                        <!-- Work -->
                        <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".1s">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="<?php echo e(url('img/800x400/01.jpg')); ?>" alt="Portfolio Image">
                            </div>
                            <div class="work-content">
                                <h3 class="color-white margin-b-5">
                                    <?php if($lang == 'az'): ?>
                                    Vaqonlar
                                    <?php elseif($lang == 'en'): ?>
                                    Trains
                                    <?php elseif($lang == 'ru'): ?>
                                    Поезда
                                    <?php endif; ?>
                                </h3>
                                <p class="color-white margin-b-0">Bu linkə keçid edərək vaqonlar haqqında faydalı məlumatları görəcəksiz</p>
                            </div>
                            <a class="content-wrapper-link" href="<?php echo e($lang.'/train'); ?>"></a>
                        </div>
                        <!-- End Work -->
                    </div>
                    <div class="masonry-grid-item col-xs-6 col-sm-6 col-md-4">
                        <!-- Work -->
                        <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".2s">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="<?php echo e(url('img/397x400/01.jpg')); ?>" alt="Portfolio Image">
                            </div>
                            <div class="work-content">
                                <h3 class="color-white margin-b-5">
                                    <?php if($lang == 'az'): ?>
                                    Konteynerlər
                                    <?php elseif($lang == 'en'): ?>
                                    Containers
                                    <?php elseif($lang == 'ru'): ?>
                                    Контейнеры
                                    <?php endif; ?></h3>
                                <p class="color-white margin-b-0">Konteynerlərin həcmi, tipləri və digər məlumatları bu linkə keçərək əldə edə bilərsiniz</p>
                            </div>
                            <a class="content-wrapper-link" href="<?php echo e($lang.'/container'); ?>"></a>
                        </div>
                        <!-- End Work -->
                    </div>
                    <div class="masonry-grid-item col-xs-6 col-sm-6 col-md-4">
                        <!-- Work -->
                        <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".3s">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="<?php echo e(url('img/397x300/01.jpg')); ?>" alt="Portfolio Image">
                            </div>
                            <div class="work-content">
                                <h3 class="color-white margin-b-5">Malların Yüklənməsi</h3>
                                <p class="color-white margin-b-0">Yükünüzün zədə almadan yüklənməsi və daşınması</p>
                            </div>
                            <a class="content-wrapper-link" href="#"></a>
                        </div>
                        <!-- End Work -->
                    </div>
                    <div class="masonry-grid-item col-xs-6 col-sm-6 col-md-4">
                        <!-- Work -->
                        <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".4s">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="<?php echo e(url('img/397x300/02.jpg')); ?>" alt="Portfolio Image">
                            </div>
                            <div class="work-content">
                                <h3 class="color-white margin-b-5">Anbar</h3>
                                <p class="color-white margin-b-0">Yükün anbara yığılması</p>
                            </div>
                            <a class="content-wrapper-link" href="#"></a>
                        </div>
                        <!-- End Work -->
                    </div>
                    <div class="masonry-grid-item col-xs-6 col-sm-6 col-md-4">
                        <!-- Work -->
                        <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".5s">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="<?php echo e(url('img/397x300/03.jpg')); ?>" alt="Portfolio Image">
                            </div>
                            <div class="work-content">
                                <h3 class="color-white margin-b-5">Tankerlər</h3>
                                <p class="color-white margin-b-0">Tankerlərimiz haqqında məlumatlar</p>
                            </div>
                            <a class="content-wrapper-link" href="#"></a>
                        </div>
                        <!-- End Work -->
                    </div>
                </div>
                <!-- End Masonry Grid -->
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>