@extends('admin.layout')

@section('content')

asd

@endsection