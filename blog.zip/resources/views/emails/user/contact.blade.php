{{$request->email}} terefinden gonderilen email


nomresi - {{$request->number}}

adi - {{$request->name}}


Mesaji:
{{$request->message}}